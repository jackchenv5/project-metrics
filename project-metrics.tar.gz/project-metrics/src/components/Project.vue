<template>
  <Home></Home>
  <el-container>
    <h1> hello world!</h1>
  </el-container>
</template>
<script setup>
  import Home from './Home.vue'
</script>